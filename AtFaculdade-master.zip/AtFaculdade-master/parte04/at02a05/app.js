// Faça um programa, com uma função que necessite de três argumentos, e que forneça a soma desses três argumentos através de uma função. Seu script também deve fornecer a média dos três números, através de uma segunda função que chama a primeira.
// const num = []
// num.push(prompt("digite um numero:"))
// num.push(prompt("digite outro numero:"))
// num.push(prompt("digite outro numero:"))
// let soma = parseInt(num[0]) + parseInt(num[1]) + parseInt(num[2])
// let media = soma / 3
// alert(`A soma é: ${soma} e a média é: ${media}`) 

// Faça um programa que recebe três números do usuário, e identifica o maior através de uma função e o menor número através de outra função.
// const num = []
// num.push(prompt("digite um numero:"))
// num.push(prompt("digite outro numero:"))
// num.push(prompt("digite outro numero:"))
// let maior = Math.max(...num) 
// let menor = Math.min(...num)
// alert(`O maior é: ${maior} e o menor é: ${menor}`) 

// A probabilidade de dar um valor em um dado é 1/6 (uma em 6). Faça um script em JavaScript que simule 1 milhão de lançamentos de dados e mostre a frequência que deu para cada número.
// function buscaNum() {
//         return parseInt(Math.random() * 6 + 1);
//   }
// function repete(n) {
//     const res = []
//     for(let i = 0; i < n; ++i){
//         res.push(buscaNum())
//     }
//     return res
// }
// function contaItems(objeto) {
//     const countMap = Object.create(null);
  
//     for (const element of objeto) {
//       countMap[element] = (countMap[element] || 0) + 1;
//     }
    
//     return countMap;
//   }
// console.log(contaItems(repete(1000000)))

// Crie uma função que recebe um inteiro positivo e teste para saber se ele é primo ou não. Faça um script que recebe um inteiro n e mostra todos os primos, de 1 até n.
let num = parseInt(prompt("Digite o numero:"))
let resultado = []
let n

for (n = 1;n < num; n++) {
    if (num % n == 0 && n != 1) {
        resultado += 1
    }}

if (resultado != 0) {
    alert(`${num} Não é um número primo.`)
} else {
    alert(`${num} É um número primo`)
}

function mostraTodosPrimos(limit) {
    for(let numero = 2; numero <= limit; numero++) {
        if(nums(numero)) console.log(numero)
    }
}

function nums(numero) {
    for(let divide =2; divide < numero; divide++) {
        if(numero % divide === 0) {
            return false;
        }
    }
    return true;
}

mostraTodosPrimos(num)