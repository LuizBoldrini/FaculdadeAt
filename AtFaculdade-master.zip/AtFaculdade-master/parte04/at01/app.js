function ConverterCelsiusParafahrenheit() {
    let tempElemento = document.getElementById("temperatura")
    let temp = tempElemento.value
    let tempNumerico = parseFloat(temp)
    
    let conversao = (tempNumerico * 9/5) + 32

    let elementoConvertido = document.getElementById("valorConvertido")

    let tempConvertida = `${conversao} graus fahrenheit`
    elementoConvertido.innerHTML = tempConvertida
    document.getElementById("valorConvertido")
}

function ConverterfahrenheitParaCelsius() {
    let tempElemento = document.getElementById("temperatura")
    let temp = tempElemento.value
    let tempNumerico = parseFloat(temp)
    
    let conversao = (tempNumerico - 32) * 5/9

    let elementoConvertido = document.getElementById("valorConvertido")

    let tempConvertida = `${conversao} graus Celsius`
    elementoConvertido.innerHTML = tempConvertida
    document.getElementById("valorConvertido")
}