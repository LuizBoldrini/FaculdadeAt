// Escreva um programa para ler 2 valores (considere que  não serão informados valoresiguais) e escrever o maior deles.
// const num = []
// num.push(prompt("digite um numero:"))
// num.push(prompt("digite outro numero:"))
// let max = Math.max(...num)
// alert(max)

// Escreva um programa para ler o ano de nascimento de uma pessoa e escrever umamensagem que diga se ela poderá ou não votar este ano (não é necessário considerar omês em que ela nasceu).
// const idade = []
// idade.push(prompt("digite seu ano de nascimeto:"))
// let idadeDec = parseInt(idade)
// let sub = 2022 - idadeDec
// if(sub >= 16 ) {
//     alert(`Sua idade é ${sub}, pode votar`)
// } else {
//     alert(`Sua idade é ${sub}, ainda não possui idade suficiente`)
// }

// Escreva um programa que verifique a validade de uma senha fornecida pelo usuário. Asenha válida é o número 1234. Devem ser impressas as seguintes mensagens:ACESSO PERMITIDO caso a senha seja válida.ACESSO NEGADO caso a senha seja inválida.
// const senha = prompt("Digite sua senha:")
// if(senha == 1234 ) {
//     alert("ACESSO PERMITIDO")
// } else {
//     alert("ACESSO NEGADO")
// }

// As maçãs custam R$ 0,30 cada se forem compradas menos do que uma dúzia, e R$ 0,25se forem compradas pelo menos doze. Escreva um programa que leia o número de maçãscompradas, calcule e escreva o valor total da compra.
// const quant = []
// quant.push(prompt("digite seu ano de nascimeto:"))
// let quantDec = parseInt(quant)
// if(quantDec <= 6 ) {
//     let quantCal = quantDec * 0.30
//     alert(`Você comprou ${quantDec} maçãs, valor total R$${quantCal} `)
// } if(quantDec > 6){
//     let quantCal = quantDec * 0.25
//     alert(`Você comprou ${quantDec} maçãs, valor total R$${quantCal} `)
// }

// Escreva um programa para ler 3 valores inteiros (considere que  não serão lidos valoresiguais) e escrevê-los em ordem crescente.
// const num = []
// num.push(prompt("digite o primeiro valor:"))
// num.push(prompt("digite o segundo valor:"))
// num.push(prompt("digite o terceiro valor:"))
// num.sort()
// alert(num)

// Tendo como entrada a altura e o sexo (codificado da seguinte forma: 1:feminino2:masculino) de uma pessoa, construa um programa que calcule e imprima seu peso ideal,utilizando as seguintes Fórmulas:- para homens: (72.7 * Altura) – 58- para mulheres: (62.1 * Altura) – 44.7
// const sexo = []
// const altura = []
// sexo.push(prompt("Digite 1 para o sexo feminino ou 2 para masculino:"))
// altura.push(prompt("Digite sua altura(ex: 1.75):"))
// if(sexo == 1) {
//     let cal = (62.1 * altura) - 44.7
//     alert(`Seu peso ideal é: ${cal}`)
// } if(sexo == 2) {
//     let cal = (72.7 * altura) - 58
//     alert(`Seu peso ideal é: ${cal}`)
// }

// Escreva um programa para ler o número de lados de um polígono regular e a medida dolado (em cm). Calcular e imprimir o seguinte:− Se o número de lados for igual a 3 escrever TRI NGULO e o valor da área− Se o número de lados for igual a 4 escrever QUADRADO e o valor da sua área.− Se o número de lados for igual a 5 escrever PENTÁGONO.
// Acrescente as seguintes mensagens à solução do exercício anterior conforme o caso.− Caso o número de lados seja inferior a 3 escrever NÃO É UM POLÍGONO.− Caso o número de lados seja superior a 5 escrever POLÍGONO NÃO IDENTIFICADO.
// const lados = []
// const area = []
// lados.push(prompt("Seu polígono possui 3, 4 ou 5 lados?"))
// if(lados < 3) {
//     alert("NÃO É UM POLÍGONO")
// }if(lados == 3) {
//     area.push(prompt("Digite o valor da base em cm:"))
//     area.push(prompt("Digite o valor da altura área em cm:"))
//     let calarea = (area[0] * area[1] ) / 2
//     alert(`Este poligono é um TRIÂNGULO de ${calarea} cm²`)
// }if(lados == 4) {
//     area.push(prompt("Digite o valor da base em cm:"))
//     area.push(prompt("Digite o valor da altura área em cm:"))
//     let calarea = (area[0] * area[1] )
//     alert(`Este poligono é um QUADRADO de ${calarea} cm²`)
// }if(lados == 5) {
//     alert("Este poligono é um PENTÁGONO")
// }if(lados > 5 ) {
//     alert("POLÍGONO NÃO IDENTIFICADO")
// }

// Escreva um programa para ler 3 valores inteiros e escrever o maior deles. Considere queo usuário não informará valores iguais.
// const num = []
// num.push(prompt("digite o primeiro numero:"))
// num.push(prompt("digite o segundo numero:"))
// num.push(prompt("digite o terceiro numero:"))
// let max = Math.max(...num)
// alert(max)

// Escreva um programa que leia as medidas dos lados de um triângulo e escreva se ele éEquilátero, Isósceles ou Escaleno. Sendo que:− Triângulo Equilátero: possui os 3 lados iguais.− Triângulo Isóscele: possui 2 lados iguais.− Triângulo Escaleno: possui 3 lados diferentes.
// const num = []
// num.push(prompt("digite o primeiro lado:"))
// num.push(prompt("digite o segundo lado:"))
// num.push(prompt("digite o terceiro lado:"))
// if(num[0] == num[1] && num[0] == num[2]) {
//     alert("Este triângulo é equilátero")
// }if((num[0] == num[1] && num[0] != num[2]) || (num[0] != num[1] && num[0] == num[2]) || (num[1] == num[2] && num[1] != num[0]) ) {
//     alert("Este triângulo é isócele")
// }if(num[0] != num[1] && num[0] != num[2]) {
//     alert("Este triângulo é escaleno")
// }

// Escreva um programa que leia o valor de 3 ângulos de um triângulo e escreva se otriângulo é Acutângulo, Retângulo ou Obtusângulo. Sendo que:− Triângulo Retângulo: possui um ângulo reto. (igual a 90º)− Triângulo Obtusângulo: possui um ângulo obtuso. (maior que90º)− Triângulo Acutângulo: possui três ângulos agudos. (menor que 90º).
const ang = []
ang.push(prompt("Digite o primeiro ângulo:"))
ang.push(prompt("Digite o segundo ângulo:"))
ang.push(prompt("Digite o terceiro ângulo:"))
if(ang[0] == 90 || ang[1] == 90 || ang[2] == 90 ) {
    alert("Este é um triângulo retângulo")
}if(ang[0] > 90 || ang[1] > 90 || ang[2] > 90 ) {
    alert("Este é um triângulo obtusângulo")
}if(ang[0] < 90 || ang[1] < 90 || ang[2] < 90 ) {
    alert("Este é um triângulo acutângulo")
}
