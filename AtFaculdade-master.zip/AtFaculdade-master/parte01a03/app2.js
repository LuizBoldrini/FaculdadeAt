// 1. Faça um programa que leia e valide as seguintes informações:Dica: se sua variável é **texto**, o tamanho dela está armazenado em: texto.length 1. Nome: maior que 3 caracteres; 2. Idade: entre 0 e 150; 3. Salário: maior que zero; 4. Sexo: 'f' ou 'm'; 5. Estado Civil: 's', 'c', 'v', 'd';
// let nome = []
// nome.push(prompt("Digite seu nome:"))
// if(nome[0].length > 3) {
//     alert(`Seu nome: ${nome}, é válido`)
// } else{
//     alert("Seu nome precisa ter mais de 3 caracteres")
// }
// let idade = []
// idade.push(prompt("Digite sua idade:"))
// if(parseInt(idade) >= 0 && parseInt(idade) <= 150) {
//     alert(`Sua idade: ${idade}, é válido`)
// } else{
//     alert("Sua idade precisa ser entre 0 e 150")
// }
// let salario = []
// salario.push(prompt("Digite seu salário:"))
// if(parseInt(salario) > 0) {
//     alert(`Seu salário: ${salario}, é válido`)
// } else{
//     alert("Seu salário precisa ser maior que 0")
// }
// let sexo = []
// sexo.push(prompt("Digite F(feminino) ou M(masculino):"))
// if(sexo == "F" || sexo == "f") {
//     alert("Possui sexo feminino")
// }else if(sexo == "M" || sexo == "m") {
//     alert("Possui sexo masculino")
// }
//  else{
//     alert(`${sexo} não possui sexo correspondente`)
// }
// let estado = []
// estado.push(prompt("Digite seu estado civil: 's', 'c', 'v' ou 'd'"))
// if(estado == "s" || estado == "S") {
//     alert("Você é solteiro(a)")
// }else if(estado == "c" || estado == "C") {
//     alert("Você é casado(a)")
// }else if(estado == "v" || estado == "V") {
//     alert("Você é viúvo(a)")
// }else if(estado == "d" || estado == "D") {
//     alert("Você é divorciado(a)")
// }
//  else{
//     alert(`${estado} não possui correspondente`)
// }

// Supondo que a população de um país A seja da ordem de 80000 habitantes com uma taxa anual de crescimento de 3% e que a população de B seja 200000 habitantes com uma taxa de crescimento de 1.5%. Faça um programa que calcule e escreva o número de anos necessários para que a população do país A ultrapasse ou iguale a população do país B, mantidas as taxas de crescimento.
// let cidadeA = 80000
// let cidadeB = 200000
// for (let ano = 1;; ano++) {
//     cidadeA = cidadeA * 1.03
//     cidadeB = cidadeB * 1.015
//     if (cidadeA > cidadeB) {
//         alert(`Foram necessários ${ano} anos para a cidade A ultrapassar ou igualar a cidade B em população`)
//         break};
// }

// Altere o programa anterior permitindo ao usuário informar as populações e as taxas de crescimento iniciais. Valide a entrada e permita repetir a operação.
// let cidadeA = prompt("Digite o valor da população da cidade A:")
// let taxaA = prompt("Digite o valor da taxa de crescimento da população da cidade A:")
// let cidadeB = prompt("Digite o valor da população da cidade B:")
// let taxaB = prompt("Digite o valor da taxa de crescimento da população da cidade B:")
// for (let ano = 1;; ano++) {
//     cidadeA = parseInt(cidadeA) * (1 + parseFloat(taxaA))
//     cidadeB = parseInt(cidadeB) * (1 + parseFloat(taxaB))
//     if (cidadeA > cidadeB) {
//         alert(`Foram necessários ${ano} anos para a cidade A ultrapassar ou igualar a cidade B em população`)
//         break};
// }

// Faça um programa que imprima na tela os números de 1 a 20, um abaixo do outro. Depois modifique o programa para que ele mostre os números um ao lado do outro.
// let i
// for (i = 1;; i++) {
//     console.log(i);
//     if (i > 19) break;
// }
// let mostraNum = Array(i).fill(1).map((x, y) => x + y);
// console.log(mostraNum);

// Faça um programa que leia 5 números e informe o maior número.
// const num = []
// num.push(prompt("digite um numero:"))
// num.push(prompt("digite outro numero:"))
// num.push(prompt("digite outro numero:"))
// num.push(prompt("digite outro numero:"))
// num.push(prompt("digite outro numero:"))
// let max = Math.max(...num)
// alert(max)

// Faça um programa que leia 5 números e informe a soma e a média dos números.
// const num = []
// num.push(prompt("digite um numero:"))
// num.push(prompt("digite outro numero:"))
// num.push(prompt("digite outro numero:"))
// num.push(prompt("digite outro numero:"))
// num.push(prompt("digite outro numero:"))
// let soma = parseInt(num[0]) + parseInt(num[1]) + parseInt(num[2]) + parseInt(num[3]) + parseInt(num[4])
// alert(soma)

// Faça um programa que imprima na tela apenas os números ímpares entre 1 e 50.
// let i
// for (i = 0;i < 50; i++) {
//     if ((i % 2) != 0) {
//         console.log(+ i)
//     };
// }

// Faça um programa que receba dois números inteiros e gere os números inteiros que estão no intervalo compreendido por eles.
// let i
// let numMenor = prompt("Digite o valor mais baixo")
// let numMaior = prompt("Digite o valor mais alto")
// for (i = parseInt(numMenor) + 1 ;i < parseInt(numMaior); i++) {
//     console.log(i);
// }

// Altere o programa anterior para mostrar no final a soma dos números.
// let i
// let numMenor = prompt("Digite o valor mais baixo")
// let numMaior = prompt("Digite o valor mais alto")
// for (i = parseInt(numMenor) + 1;i < parseInt(numMaior); i++) {
// }
// let mostraNum = Array(i).fill(1).map((x, y) => x + y);
// let soma = 0
// for(i = 0; i < mostraNum.length; i++) {
//     soma += mostraNum[i];
// }
// console.log(mostraNum)
// console.log(soma);

// Desenvolva um gerador de tabuada, capaz de gerar a tabuada de qualquer número inteiro entre 1 a 10. O usuário deve informar de qual numero ele deseja ver a tabuada.
let i 
let mult = prompt("Digite um número")
for( i = 1; i <= 10; i++) {
    console.log(`${mult} x ${i} =` + (parseInt(mult)*i))
} 