// Crie um código que consiga imprimir os tipos de 3 variáveis diferentes;
// const a = "O valor é:";
// const b = 10;
// const c = 20;
// console.log(`${a} ${b} e ${c}`)


// Crie um código capaz de calcular a raiz quadrada de um número;
// const valor = prompt("Qual valor que queria descobrir a raiz?");
// let valorDeclarado = parseInt(valor)
// let raiz = Math.sqrt(valorDeclarado)
// alert(raiz)

// Crie um código capaz de calcular a potência 2 de um número;
// const valor = prompt("Qual o valor em que queira descobrir a potência de 2?")
// let valorDeclarado = parseInt(valor)
// let valorConvertido = valorDeclarado * 2
// alert(valorConvertido)

// Crie um código que calcule a hipotenusa através do teorema de pitágoras;
// const valor1 = prompt("Digite o valor do primeiro cateto:")
// const valor2 = prompt("Digite o valor do segundo cateto:")
// let valorDeclarado1 = parseInt(valor1)
// let valorDeclarado2 = parseInt(valor2)
// let pot = ((valorDeclarado1 * 2) + (valorDeclarado2 * 2)) / 2
// alert(pot)

// Crie um código capaz de calcular a fórmula de bhaskara;
// const valorA = prompt("Digite o valor de A:")
// const valorB = prompt("Digite o valor de B:")
// const valorC = prompt("Digite o valor de C:")
// let a = parseInt(valorA)
// let b = parseInt(valorB)
// let c = parseInt(valorC)
// let delta = (b * 2) - (4 * a * c)
// let raiz1 = (-b + Math.sqrt(delta)) / (2*a)
// let raiz2 = (-b - Math.sqrt(delta)) / (2*a)
// alert(raiz1)
// alert(raiz2)

// Crie um objeto json com um ítem do tipo array, e acesse a segunda posição;
// const carro = 
//     {
//     modelo: "gol",
//     cor: "preto",
//     placa: "ABC1234"

//     }
// alert(carro.cor)

// Crie um array de string e imprima a posição 2;
// const fruta = ["pera", "uva", "melancia"]
// alert(fruta[1])

// Crie um array de string e concatene o valor da posição 2 com a posição 3;
// const fruta = ["pera", "uva", "melancia"]
// alert(`${fruta[1]} e ${fruta[2]}`)

// Crie um array e remova o índice 2;
// const fruta = ["pera", "uva", "melancia"]
// fruta.splice(2,2)
// alert(fruta)

// Crie um array e remova o primeiro ítem da lista;
// const fruta = ["pera", "uva", "melancia"]
// fruta.splice(0,1)
// alert(fruta)

// Crie um array e adicione um valor no final do array;
// const fruta = ["pera", "uva", "melancia"]
// fruta.push("laranja")
// alert(fruta)

// Crie um código utilizando a estrutura switch case e imprima qual estado correspondea sigla informada. Exemplo: RO corresponde a Rondônia, SP corresponde à SãoPaulo e ZT não corresponde a nenhum estado
var estado = prompt("Digite a sigla(em maiúsculo) do estado que está procurando")
switch (estado) {
    case 'AC':
        alert('corresponde a Acre');
        break;
    case 'AL':
        alert('corresponde a Alagoas');
        break;
    case 'AP':
        alert('corresponde a Amapá');
        break;
    case 'AM':
        alert('corresponde a Amazonas');
        break;
    case 'BA':
        alert('corresponde a Bahia');
        break;
    case 'CE':
        alert('corresponde a Ceará');
        break;
    case 'DF':
        alert('corresponde a Distrito Federal');
        break;
    case 'ES':
        alert('corresponde a Espírito Santo');
        break;
    case 'GO':
        alert('corresponde a Goiás ');
        break;
    case 'MA':
        alert('corresponde a Maranhão ');
        break;
    case 'MT':
        alert('corresponde a Mato Grosso');
        break;
    case 'MS':
        alert('corresponde a Mato Grosso do Sul');
        break;
    case 'MG':
        alert('corresponde a Minas Gerais');
        break;
    case 'PA':
        alert('corresponde a Pará');
        break;
    case 'PB':
        alert('corresponde a Paraíba');
        break;
    case 'PR':
        alert('corresponde a Paraná');
        break;
    case 'PE':
        alert('corresponde a Pernambuco');
        break;
    case 'PI':
        alert('corresponde a Piauí');
        break;
    case 'RJ':
        alert('corresponde a Rio de Janeiro');
        break;
    case 'RN':
        alert('corresponde a Rio Grande do Norte');
        break;
    case 'RS':
        alert('corresponde a Rio Grande do Sul');
        break;
    case 'RO':
        alert('corresponde a Rondônia ');
        break;
    case 'RR':
        alert('corresponde a Roraima ');
        break;
    case 'SC':
        alert('corresponde a Santa Catarina');
        break;
    case 'SP':
        alert('corresponde a São Paulo');
        break;
    case 'SE':
        alert('corresponde a Sergipe');
        break;
    case 'TO':
        alert('corresponde a Tocantins');
        break;
    default:
        alert('Nenhum estado conrespondente com esta sigla.');
}